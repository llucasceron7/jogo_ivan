import 'package:flame/components.dart';
import 'package:flutter/material.dart';
import '../game/estrela_game.dart';

class LivesText extends TextComponent with HasGameReference<EstrelaGame> {
  LivesText() : super(
    text: 'VIDAS: ❤️❤️❤️', 
    textRenderer: TextPaint(
      style: const TextStyle(
        color: Colors.redAccent, 
        fontSize: 22, 
        fontWeight: FontWeight.bold, 
        fontFamily: 'Courier New'
      ),
    ),
  );

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    position = Vector2(game.size.x - 240, 30);
  }

  void updateLives(int currentLives) {
    String hearts = '';
    for (int i = 0; i < currentLives; i++) {
      hearts += '❤️';  // 👈 Adicionado as chaves {}
    }
    if (hearts.isEmpty) {
      hearts = '❌';  // 👈 Adicionado as chaves {}
    }
    text = 'VIDAS: $hearts';
  }
}