import 'package:flame/components.dart';
import 'package:flutter/material.dart';
import '../game/estrela_game.dart';

class ScoreText extends TextComponent with HasGameReference<EstrelaGame> {
  ScoreText() : super(
    text: 'SCORE: 0  |  BEST: 0', 
    textRenderer: TextPaint(
      style: const TextStyle(
        color: Colors.white, 
        fontSize: 22, 
        fontWeight: FontWeight.bold, 
        fontFamily: 'Courier New'
      ),
    ),
  );

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    position = Vector2(30, 30);
  }

  void updateScore(int newScore, int highest) {
    text = 'SCORE: $newScore  |  BEST: $highest';
  }
}