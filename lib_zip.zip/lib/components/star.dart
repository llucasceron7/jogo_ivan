import 'dart:math';
import 'package:flame/collisions.dart';
import 'package:flame/components.dart';
import 'package:flutter/material.dart';
import '../game/estrela_game.dart';
import '../managers/sprite_manager.dart';
import '../utils/constants.dart';
import 'player.dart';

class Star extends PositionComponent 
    with HasGameReference<EstrelaGame>, CollisionCallbacks {
  final TipoEstrela tipo;
  late double speed;
  late int pontosValor;
  SpriteComponent? spriteComponent;
  late Color corParticula;
  bool usandoImagem = false;

  Star({this.tipo = TipoEstrela.normal});

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    
    String spriteKey;
    
    switch (tipo) {
      case TipoEstrela.normal:
        size = Vector2.all(40);
        pontosValor = GameConstants.normalStarPoints;
        speed = GameConstants.normalStarBaseSpeed + (game.score * 10.0);
        spriteKey = SpriteManager.starNormal;
        corParticula = Colors.cyan;
        break;
      case TipoEstrela.bonus:
        size = Vector2.all(35);
        pontosValor = GameConstants.bonusStarPoints;
        speed = GameConstants.bonusStarBaseSpeed + (game.score * 12.0);
        spriteKey = SpriteManager.starBonus;
        corParticula = Colors.red;
        break;
      case TipoEstrela.vida:
        size = Vector2.all(45);
        pontosValor = 0;
        speed = GameConstants.lifeStarBaseSpeed + (game.score * 6.0);
        spriteKey = SpriteManager.starLife;
        corParticula = Colors.green;
        break;
    }
    
    // Tenta carregar a imagem
    final sprite = game.spriteManager.getSprite(spriteKey);
    
    if (sprite != null) {
      spriteComponent = SpriteComponent(
        sprite: sprite,
        size: size,
        anchor: Anchor.center,
      );
      await add(spriteComponent!);
      spriteComponent!.position = size / 2;
      usandoImagem = true;
    } else {
      usandoImagem = false;
    }
    
    final randomX = Random().nextDouble() * (game.size.x - size.x);
    position = Vector2(randomX, -size.y);

    await add(RectangleHitbox());
  }

  @override
  void update(double dt) {
    super.update(dt);
    position.y += speed * dt;

    if (usandoImagem && spriteComponent != null) {
      spriteComponent!.position = size / 2;
    }

    if (position.y > game.size.y) {
      if (tipo != TipoEstrela.vida) {
        game.loseLife();
      }
      removeFromParent();
    }
  }

  @override
  void onCollisionStart(Set<Vector2> intersectionPoints, PositionComponent other) {
    super.onCollisionStart(intersectionPoints, other);
    if (other is Player) {
      if (tipo == TipoEstrela.vida) {
        game.recuperarVida();
        game.ganharPontos(0, corParticula, position);
      } else {
        game.ganharPontos(pontosValor, corParticula, position);
      }
      removeFromParent();
    }
  }

  @override
  void render(Canvas canvas) {
    if (!usandoImagem) {
      // Fallback visual
      final paint = Paint()..color = corParticula;
      
      final paintBrilho = Paint()
        ..color = corParticula.withValues(alpha: 0.3)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6);
      
      canvas.save();
      canvas.translate(size.x / 2, size.y / 2);
      canvas.rotate(pi / 4);
      
      final rectCentro = Rect.fromCenter(
        center: Offset.zero, 
        width: size.x, 
        height: size.y
      );
      canvas.drawRect(rectCentro, paintBrilho);
      canvas.drawRect(rectCentro, paint);
      canvas.restore();
    }
    super.render(canvas);
  }
}