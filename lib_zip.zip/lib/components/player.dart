import 'package:flame/collisions.dart';
import 'package:flame/components.dart';
import 'package:flutter/material.dart';
import '../game/estrela_game.dart';
import '../managers/sprite_manager.dart';
import '../utils/constants.dart';

class Player extends PositionComponent 
    with HasGameReference<EstrelaGame>, CollisionCallbacks {
  double speed = GameConstants.playerSpeed;
  SpriteComponent? spriteComponent;
  bool usandoImagem = false;
  double efeitoTimer = 0;

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    
    size = Vector2(80, 80);
    resetPosition();
    
    // Tenta carregar a imagem
    final sprite = game.spriteManager.getSprite(SpriteManager.player);
    
    if (sprite != null) {
      spriteComponent = SpriteComponent(
        sprite: sprite,
        size: size,
        anchor: Anchor.center,
      );
      await add(spriteComponent!);
      spriteComponent!.position = size / 2;
      usandoImagem = true;
      debugPrint('✅ Player: Imagem carregada com sucesso!');
    } else {
      debugPrint('⚠️ Player: Usando fallback visual');
      usandoImagem = false;
    }
    
    await add(RectangleHitbox());
  }

  void resetPosition() {
    position = Vector2(
      game.size.x / 2 - size.x / 2,
      game.size.y - 100
    );
  }

  void dispararBrilho(Color cor) {
    efeitoTimer = 0.15;
  }

  @override
  void update(double dt) {
    super.update(dt);
    if (efeitoTimer > 0) {
      efeitoTimer -= dt;
    }
    
    if (usandoImagem && spriteComponent != null) {
      spriteComponent!.position = size / 2;
    }
  }

  @override
  void render(Canvas canvas) {
    if (!usandoImagem) {
      // Fallback visual
      final rect = size.toRect();
      final rrect = RRect.fromRectAndRadius(rect, const Radius.circular(10));
      final paintPrincipal = Paint()..color = const Color(0xFF00E5FF);
      canvas.drawRRect(rrect, paintPrincipal);
    }
    super.render(canvas);
  }

  void moveLeft() {
    if (position.x > 0) {
      position.x -= speed;
    }
  }

  void moveRight() {
    if (position.x < game.size.x - size.x) {
      position.x += speed;
    }
  }
}