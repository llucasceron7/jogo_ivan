import 'package:flutter/material.dart';
import 'package:flame/game.dart';
import 'game/estrela_game.dart';
import 'widgets/menu_inicial_widget.dart';
import 'widgets/game_over_widget.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Star Catcher 2D',
      home: Scaffold(
        body: GameWidget<EstrelaGame>(
          game: EstrelaGame(),
          overlayBuilderMap: {
            'MainMenu': (context, game) => MenuInicialWidget(game: game),
            'GameOver': (context, game) => GameOverWidget(game: game),
          },
          initialActiveOverlays: const ['MainMenu'],
        ),
      ),
    );
  }
}