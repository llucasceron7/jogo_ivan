import 'package:flutter/material.dart';
import '../game/estrela_game.dart';

class MenuInicialWidget extends StatelessWidget {
  final EstrelaGame game;
  const MenuInicialWidget({super.key, required this.game});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black.withValues(alpha: 0.9), // 👈 Substituído .withOpacity()
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              'STAR CATCHER 2D',
              style: TextStyle(
                color: Colors.yellow, 
                fontSize: 44, 
                fontWeight: FontWeight.bold, 
                fontFamily: 'Courier New', 
                decoration: TextDecoration.none
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              '⭐ Amarela: 1 Ponto\n🛑 Vermelha: 3 Pontos (Rápida!)\n💚 Verde: +1 Vida',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.white70, 
                fontSize: 16, 
                fontFamily: 'Courier New', 
                decoration: TextDecoration.none, 
                height: 1.5
              ),
            ),
            const SizedBox(height: 45),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF00E5FF),
                padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 16),
              ),
              onPressed: () => game.comecarJogo(),
              child: const Text(
                'JOGAR AGORA', 
                style: TextStyle(
                  fontSize: 22, 
                  color: Colors.black, 
                  fontWeight: FontWeight.bold
                )
              ),
            ),
          ],
        ),
      ),
    );
  }
}