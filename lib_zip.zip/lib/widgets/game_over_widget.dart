import 'package:flutter/material.dart';
import '../game/estrela_game.dart';

class GameOverWidget extends StatelessWidget {
  final EstrelaGame game;
  const GameOverWidget({super.key, required this.game});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black.withValues(alpha: 0.85), // 👈 Substituído .withOpacity()
      child: Center(
        child: Container(
          padding: const EdgeInsets.all(35),
          decoration: BoxDecoration(
            color: const Color(0xFF1A0A0A), 
            borderRadius: BorderRadius.circular(12), 
            border: Border.all(color: Colors.redAccent, width: 2)
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'FIM DE JOGO',
                style: TextStyle(
                  color: Colors.redAccent, 
                  fontSize: 44, 
                  fontWeight: FontWeight.bold, 
                  fontFamily: 'Courier New', 
                  decoration: TextDecoration.none
                ),
              ),
              const SizedBox(height: 20),
              Text(
                'Pontos Feitos: ${game.score}\nMaior Recorde: ${game.highScore}',
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: Colors.white, 
                  fontSize: 20, 
                  fontFamily: 'Courier New', 
                  decoration: TextDecoration.none, 
                  height: 1.4
                ),
              ),
              const SizedBox(height: 35),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.redAccent, 
                  padding: const EdgeInsets.symmetric(horizontal: 35, vertical: 14)
                ),
                onPressed: () => game.comecarJogo(),
                child: const Text(
                  'REINICIAR', 
                  style: TextStyle(
                    fontSize: 20, 
                    color: Colors.white, 
                    fontWeight: FontWeight.bold
                  )
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}