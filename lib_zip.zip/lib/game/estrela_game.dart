import 'dart:math';
import 'package:flame/components.dart';
import 'package:flame/game.dart';
import 'package:flame/events.dart';
import 'package:flame/particles.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../components/player.dart';
import '../components/star.dart';
import '../components/score_text.dart';
import '../components/lives_text.dart';
import '../managers/sprite_manager.dart'; // 👈 IMPORTAR O GERENCIADOR
import '../utils/constants.dart';

class EstrelaGame extends FlameGame 
    with HasCollisionDetection, TapCallbacks, KeyboardEvents {
  late Player player;
  late ScoreText scoreText;
  late LivesText livesText;
  late SpriteManager spriteManager; // 👈 GERENCIADOR DE SPRITES
  
  int score = 0;
  int highScore = 0;
  int lives = 3;
  double spawnTimer = 0;
  double currentSpawnInterval = GameConstants.initialSpawnInterval;
  bool isPlaying = false;
  final Random random = Random();

  @override
  Color backgroundColor() => GameConstants.backgroundColor;

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    
    // Inicializa o gerenciador de sprites
    spriteManager = SpriteManager();
    await spriteManager.initialize(this);
    
    // Cria os componentes do jogo
    player = Player();
    await add(player);

    scoreText = ScoreText();
    await add(scoreText);

    livesText = LivesText();
    await add(livesText);

    overlays.add('MainMenu');
  }

  void comecarJogo() {
    score = 0;
    lives = 3;
    currentSpawnInterval = GameConstants.initialSpawnInterval;
    isPlaying = true;
    
    scoreText.updateScore(score, highScore);
    livesText.updateLives(lives);
    player.resetPosition();

    // Limpa objetos antigos da tela
    for (final child in children) {
      if (child is Star || child is ParticleSystemComponent) {
        child.removeFromParent();
      }
    }

    overlays.remove('MainMenu');
    overlays.remove('GameOver');
  }

  @override
  void update(double dt) {
    if (!isPlaying) return;
    super.update(dt);
    
    spawnTimer += dt;
    if (spawnTimer >= currentSpawnInterval) {
      double tipoSorteio = random.nextDouble();
      if (tipoSorteio < 0.10) {
        add(Star(tipo: TipoEstrela.vida));
      } else if (tipoSorteio < 0.25) {
        add(Star(tipo: TipoEstrela.bonus));
      } else {
        add(Star(tipo: TipoEstrela.normal));
      }
      spawnTimer = 0;
    }
  }

  @override
  KeyEventResult onKeyEvent(KeyEvent event, Set<LogicalKeyboardKey> keysPressed) {
    if (!isPlaying) return KeyEventResult.ignored;

    final isKeyDown = event is KeyDownEvent || event is KeyRepeatEvent;
    if (isKeyDown) {
      if (keysPressed.contains(LogicalKeyboardKey.arrowLeft) || 
          keysPressed.contains(LogicalKeyboardKey.keyA)) {
        player.moveLeft();
      }
      if (keysPressed.contains(LogicalKeyboardKey.arrowRight) || 
          keysPressed.contains(LogicalKeyboardKey.keyD)) {
        player.moveRight();
      }
    }
    return KeyEventResult.handled;
  }

  @override
  void onTapDown(TapDownEvent event) {
    if (!isPlaying) return;
    super.onTapDown(event);
    if (event.localPosition.x < size.x / 2) {
      player.moveLeft();
    } else {
      player.moveRight();
    }
  }

  void ganharPontos(int pontos, Color corParticula, Vector2 posicaoEstrela) {
    score += pontos;
    if (score > highScore) highScore = score;
    scoreText.updateScore(score, highScore);

    _criarExplosaoParticulas(corParticula, posicaoEstrela);
    player.dispararBrilho(corParticula);
  }

  void _criarExplosaoParticulas(Color cor, Vector2 posicao) {
    for (int i = 0; i < GameConstants.particleCount; i++) {
      add(
        ParticleSystemComponent(
          particle: Particle.generate(
            count: 1,
            lifespan: GameConstants.particleLifespan,
            generator: (_) => CircleParticle(
              radius: 2.0 + random.nextDouble() * 3,
              paint: Paint()..color = cor,
            ),
          ),
          position: posicao,
        ),
      );
    }
  }

  void recuperarVida() {
    if (lives < GameConstants.maxLives) {
      lives += 1;
      livesText.updateLives(lives);
      _criarExplosaoParticulas(Colors.green, player.position);
    }
  }

  void loseLife() {
    lives -= 1;
    livesText.updateLives(lives);
    
    if (lives > 0) {
      _criarExplosaoParticulas(Colors.red, player.position);
    }

    if (lives <= 0) {
      isPlaying = false;
      overlays.add('GameOver');
    }
  }
}