import 'package:flutter/material.dart';

class GameConstants {
  // Cores
  static const Color backgroundColor = Color(0xFF0A0A0E);
  static const Color playerNormalColor = Color(0xFF00E5FF);
  static const Color starNormalColor = Color(0xFFFFD600);
  static const Color starBonusColor = Color(0xFFFF1744);
  static const Color starLifeColor = Color(0xFF00E676);
  
  // Dimensões do Player
  static const double playerWidth = 110.0;
  static const double playerHeight = 22.0;
  static const double playerSpeed = 45.0;
  
  // Configurações do Jogo
  static const double initialSpawnInterval = 1.5;
  static const int maxLives = 5;
  static const double particleLifespan = 0.4;
  static const int particleCount = 15;
  
  // Pontuação
  static const int normalStarPoints = 1;
  static const int bonusStarPoints = 3;
  
  // Velocidades
  static const double normalStarBaseSpeed = 210.0;
  static const double bonusStarBaseSpeed = 340.0;
  static const double lifeStarBaseSpeed = 180.0;
}

enum TipoEstrela { normal, bonus, vida }