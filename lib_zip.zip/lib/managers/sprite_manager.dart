import 'package:flame/components.dart';
import 'package:flutter/foundation.dart';
import '../game/estrela_game.dart';

class SpriteManager {
  static final SpriteManager _instance = SpriteManager._internal();
  factory SpriteManager() => _instance;
  SpriteManager._internal();
  
  late EstrelaGame game;
  bool _isInitialized = false;
  
  final Map<String, Sprite> _spriteCache = {};
  
  static const String player = 'player';
  static const String starNormal = 'star_normal';
  static const String starBonus = 'star_bonus';
  static const String starLife = 'star_life';
  
  // CAMINHOS CORRETOS - sem duplicação
 final Map<String, String> _spritePaths = {
  player: 'monstro/monstro.png',        // ← sem assets/images/
  starNormal: 'gelo/bola_gelo.png',     // ← sem assets/images/
  starBonus: 'fogo/bola_fogo.png',      // ← sem assets/images/
  starLife: 'gelo/bola_gelo.png',       // ← sem assets/images/
};

  Future<void> initialize(EstrelaGame gameRef) async {
    if (_isInitialized) return;
    
    game = gameRef;
    
    debugPrint('🚀 Iniciando carregamento de sprites...');
    
    for (var entry in _spritePaths.entries) {
      await _loadSprite(entry.key, entry.value);
    }
    
    _isInitialized = true;
    debugPrint('✅ SpriteManager: ${_spriteCache.length} sprites carregados!');
  }
  
  Future<void> _loadSprite(String key, String path) async {
    try {
      debugPrint('📂 Carregando: $path');
      final image = await game.images.load(path);
      final sprite = Sprite(image);
      _spriteCache[key] = sprite;
      debugPrint('✅ $key carregado (${image.width}x${image.height})');
    } catch (e) {
      debugPrint('❌ Erro ao carregar $key: $e');
    }
  }
  
  Sprite? getSprite(String key) {
    final sprite = _spriteCache[key];
    if (sprite == null) {
      debugPrint('⚠️ Sprite não encontrado: $key');
    }
    return sprite;
  }
  
  bool hasSprite(String key) => _spriteCache.containsKey(key);
  
  void dispose() {
    _spriteCache.clear();
    _isInitialized = false;
  }
}